// Import global stylesheet
import './styles/main.css';
