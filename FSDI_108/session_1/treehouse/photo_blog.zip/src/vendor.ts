// angular
import '@angular/core';
import '@angular/common';
import '@angular/platform-browser';
import '@angular/platform-browser-dynamic';

// 3rd party
import 'core-js';
import 'rxjs';